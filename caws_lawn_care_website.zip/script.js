// script.js

document.addEventListener('DOMContentLoaded', () => {
  const reviewForm = document.getElementById('review-form');
  const reviewList = document.getElementById('review-list');

  // Load reviews from localStorage
  const loadReviews = () => {
    const reviews = JSON.parse(localStorage.getItem('cawsReviews')) || [];
    reviewList.innerHTML = '';
    reviews.forEach(({ name, message }) => {
      const review = document.createElement('div');
      review.className = 'review';
      review.innerHTML = `<strong>${name}</strong><p>${message}</p>`;
      reviewList.appendChild(review);
    });
  };

  // Save review
  reviewForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const message = document.getElementById('message').value.trim();
    if (!name || !message) return;

    const newReview = { name, message };
    const existingReviews = JSON.parse(localStorage.getItem('cawsReviews')) || [];
    existingReviews.unshift(newReview);
    localStorage.setItem('cawsReviews', JSON.stringify(existingReviews));

    reviewForm.reset();
    loadReviews();
  });

  loadReviews();
});
